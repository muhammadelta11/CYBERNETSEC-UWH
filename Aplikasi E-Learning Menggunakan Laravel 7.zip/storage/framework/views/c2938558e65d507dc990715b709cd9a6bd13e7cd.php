<?php $__env->startSection('content'); ?>

<!--::review_part start::-->
<section class="special_cource padding_top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5">
                <div class="section_tittle text-center">
                    <h2>Podcast</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $podcasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-lg-4 mb-2">
                <a href="<?php echo e(route('podcast.detail',Crypt::encrypt($item->id))); ?>">
                    <div class="single_special_cource">
                        <img src="http://img.youtube.com/vi/<?php echo e($item->url_podcast); ?>/0.jpg" class="special_img" alt="">
                        <div class="special_cource_text">
                            <div class="d-flex justify-content-between">
                                <div class="btn_4">
                                    Podcast
                                </div>
                                <a href="<?php echo e(route('podcast.detail',Crypt::encrypt($item->id))); ?>"
                                    class="btn btn-secondary">Lihat</a>
                            </div>
                            <a href="<?php echo e(route('podcast.detail',Crypt::encrypt($item->id))); ?>">
                                <h3><?php echo e($item->name_podcast); ?></h3>
                            </a>
                            <div style="white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;"><?php echo $item->description_podcast; ?></div>
                        </div>

                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row mt-3">
            <div class="col-md-12 d-flex justify-content-center">
                <?php echo e($podcasts->links()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/front/podcast/index.blade.php ENDPATH**/ ?>