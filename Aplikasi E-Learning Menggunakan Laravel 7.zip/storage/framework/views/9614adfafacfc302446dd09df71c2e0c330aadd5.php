<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e($title); ?> <?php echo e($kelas->name_kelas); ?></h4>
                <div class="card-header-action">
                    <a href="<?php echo e(route('admin.kelas.edit',Crypt::encrypt($kelas->id))); ?>" class="btn btn-warning">
                        Edit 
                    </a>
                    <a href="javascript:void(0)" onclick="alertconfirmn('<?php echo e(route('admin.kelas.hapus',Crypt::encrypt($kelas->id))); ?>')" class="btn btn-danger">
                        Hapus 
                    </a>
                    <button id="btn-back" class="btn btn-primary">
                        Kembali
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table>
                            <tr>
                                <td>Tipe Kelas</td>
                                <td class="px-2 py-1">:</td>
                                <td>
                                    <?php if($kelas->type_kelas == 0): ?>
                                    Gratis
                                    <?php elseif($kelas->type_kelas == 1): ?>
                                    Regular
                                    <?php elseif($kelas->type_kelas == 2): ?>
                                    Premium
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top">Deskripsi Kelas</td>
                                <td style="vertical-align: top" class="px-2 py-1">:</td>
                                <td style="vertical-align: top">
                                    <?php echo $kelas->description_kelas; ?>

                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('storage/' . $kelas->thumbnail)); ?>" width="100%" alt="" srcset="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4>Video Materi <?php echo e($kelas->name_kelas); ?></h4>
                <div class="card-header-action">
                    <a href="<?php echo e(route('admin.kelas.tambahvideo',Crypt::encrypt($kelas->id))); ?>" class="btn btn-primary">
                        Tambah
                    </a>
                    
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-items-center table-hover" id="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No</th>
                                <th>Judul</th>
                                <th>URL Video</th>
                                <th width="10%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kelas->video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td><?php echo e($item->name_video); ?></td>
                                <td><?php echo e($item->url_video); ?></td>
                                <td>
                                    <a href="javascript:void(0)" onclick="alertconfirmn('<?php echo e(route('admin.kelas.hapusvideo',[
                                        'id' => Crypt::encrypt($item->id),
                                        'idkelas' => Crypt::encrypt($kelas->id)
                                    ])); ?>')" class="btn btn-danger">
                                        Hapus 
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/admin/kelas/detail.blade.php ENDPATH**/ ?>