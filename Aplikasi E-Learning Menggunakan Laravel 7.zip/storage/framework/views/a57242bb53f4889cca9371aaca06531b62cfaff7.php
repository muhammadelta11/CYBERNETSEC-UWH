<?php $__env->startSection('content'); ?>

<!-- banner part start-->
<section class="banner_part">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-xl-6">
                <div class="banner_text">
                    <div class="banner_text_iner">
                        <h5>Semua orang bisa belajar</h5>
                        <h1>Belajar Disini Aja</h1>
                        <p>Dengan materi mudah dimengerti dan berbentuk video sehingga membantu proses pembelajaran anda
                        </p>
                        <a href="<?php echo e(route('kelas')); ?>" class="btn_1">Belajar Sekarang</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- banner part start-->

<!-- feature_part start-->
<section class="feature_part">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-xl-3 align-self-center">
                <div class="single_feature_text ">
                    <h2>Jenis <br> Kelas</h2>
                    <p>Berikut adalah jenis kelas yang bisa anda akses </p>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <span class="single_feature_icon"><i class="ti-layers"></i></span>
                        <h4>Gratis</h4>
                        <p>Kelas Gratis ini bisa diakses oleh semua orang yang mengunjungi web ini</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <span class="single_feature_icon"><i class="ti-new-window"></i></span>
                        <h4>Regular</h4>
                        <p>Kelas Regular hanya bisa diakses dengan cara membuat akun </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part single_feature_part_2">
                        <span class="single_service_icon style_icon"><i class="ti-light-bulb"></i></span>
                        <h4>Premium</h4>
                        <p>Kelas Premium hanya bisa diakses dengan cara membuat akun dan mengupgrade akun ke akun
                            premium</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- upcoming_event part start-->

<!-- learning part start-->
<section class="learning_part">
    <div class="container">
        <div class="row align-items-sm-center align-items-lg-stretch">
            <div class="col-md-7 col-lg-7">
                <div class="learning_img">
                    <img src="<?php echo e(asset('frontemplate')); ?>/img/learning_img.png" alt="">
                </div>
            </div>
            <div class="col-md-5 col-lg-5">
                <div class="learning_member_text">
                    <h5>Tentang Kami</h5>
                    <h2>Belajar Online Dimanapun Kapanpun</h2>
                    <?php
                    $setting = \App\Setting::first()
                    ?>
                    <?php echo $setting->about; ?>

                    <ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- learning part end-->


<!--::review_part start::-->
<section class="special_cource padding_top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5">
                <div class="section_tittle text-center">
                    <h2>Kelas Popular</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-lg-4 mb-2">
                <a href="<?php echo e(route('kelas.detail',Crypt::encrypt($item->id))); ?>">
                    <div class="single_special_cource">
                        <img src="<?php echo e(asset('storage/' . $item->thumbnail)); ?>" class="special_img" alt="">
                        <div class="special_cource_text">
                            <div class="d-flex justify-content-between">
                                <div class="btn_4">
                                    <?php if($item->type_kelas == 0): ?>
                                    Gratis
                                    <?php elseif($item->type_kelas == 1): ?>
                                    Regular
                                    <?php elseif($item->type_kelas == 2): ?>
                                    Premium
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo e(route('kelas.detail',Crypt::encrypt($item->id))); ?>"
                                    class="btn btn-secondary">Lihat</a>
                            </div>
                            <a href="<?php echo e(route('kelas.detail',Crypt::encrypt($item->id))); ?>">
                                <h3><?php echo e($item->name_kelas); ?></h3>
                            </a>
                            <div style="white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;"><?php echo $item->description_kelas; ?></div>
                        </div>

                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/front/welcome.blade.php ENDPATH**/ ?>