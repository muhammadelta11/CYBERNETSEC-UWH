<?php $__env->startSection('content'); ?>

<!-- breadcrumb start-->

<!--================ Start Course Details Area =================-->
<section class="course_details_area section_padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 course_details_left">
                <div class="main_image">
                    <img class="img-fluid" src="img/single_cource.png" alt="">
                </div>
                <div class="content_wrapper">
                    <img src="<?php echo e(asset('storage/'.$kelas->thumbnail)); ?>" width="300" alt="">
                    <h4 class="title_top"><?php echo e($kelas->name_kelas); ?></h4>
                    <div class="content">
                        <?php echo $kelas->description_kelas; ?>

                    </div>

                    <h4 class="title">Daftar Materi</h4>
                    <div class="content">
                        <ul class="course_list">
                            <?php if($kelas->video->count() < 1): ?> <li
                                class="justify-content-between align-items-center d-flex">
                                <p>Belum Ada Materi</p>
                                </li>
                                <?php else: ?>
                                <?php $__currentLoopData = $kelas->video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="justify-content-between align-items-center d-flex">
                                    <p><?php echo e($item->name_video); ?></p>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>


            <div class="col-lg-4 right-contents">
                <div class="sidebar_top">
                    <ul>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Kelas</p>
                                <span class="color"><?php echo e($kelas->name_kelas); ?></span>
                            </a>
                        </li>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Tipe Kelas </p>
                                <span>
                                    <?php if($kelas->type_kelas == 0): ?>
                                    Gratis
                                    <?php elseif($kelas->type_kelas == 1): ?>
                                    Regular
                                    <?php elseif($kelas->type_kelas == 2): ?>
                                    Premium
                                    <?php endif; ?>
                                </span>
                            </a>
                        </li>
                    </ul>
                    <?php if($kelas->video->count() > 0): ?>
                    <?php if($kelas->type_kelas == 0): ?>
                    <a href="<?php echo e(route('kelas.belajar',[
                        'id' => Crypt::encrypt($kelas->id),
                        'idvideo' => Crypt::encrypt($kelas->video[0]->id)
                    ])); ?>" class="btn_1 d-block">Belajar</a>
                    <?php else: ?>
                    <?php if(auth()->guard()->guest()): ?>
                    Anda harus membuat akun untuk mengakses kelas ini
                    <a href="<?php echo e(route('register')); ?>" class="btn_1 d-block">Buat Akun</a>
                    <?php else: ?>
                    <?php if($kelas->type_kelas == 1): ?>
                    <a href="<?php echo e(route('kelas.belajar',[
                        'id' => Crypt::encrypt($kelas->id),
                        'idvideo' => Crypt::encrypt($kelas->video[0]->id)
                    ])); ?>" class="btn_1 d-block">Belajar</a>
                    <?php else: ?>
                    <?php if(Auth::user()->role == 'premium'): ?>
                    <a href="<?php echo e(route('kelas.belajar',[
                        'id' => Crypt::encrypt($kelas->id),
                        'idvideo' => Crypt::encrypt($kelas->video[0]->id)
                    ])); ?>" class="btn_1 d-block">Belajar</a>
                    <?php else: ?>
                    Upgrade akun Anda ke premium untuk mengakses kelas ini
                    <a href="<?php echo e(route('upgradepremium')); ?>" class="btn_1 d-block">Upgrade Premium</a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php else: ?>
                    Belum Ada Materi Pada Kelas Ini
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Course Details Area =================-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/front/kelas/detail.blade.php ENDPATH**/ ?>