<?php $__env->startSection('content'); ?>
<div class="hero bg-primary text-white">
    <div class="hero-inner">
      <h2>Selamat Datang Admin</h2>
      <p class="lead">Di aplikasi e-learning ruang kelas.</p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>