<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e($title); ?></h4>
                <div class="card-header-action">
                    <a href="<?php echo e(route('admin.kelas.tambah')); ?>" class="btn btn-primary">
                        Tambah
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-items-center table-hover" id="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No</th>
                                <th>Nama Kelas</th>
                                <th>Tipe Kelas</th>
                                <th>Thumbnail</th>
                                <th width="10%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td><?php echo e($item->name_kelas); ?></td>
                                <td>
                                    <?php if($item->type_kelas == 0): ?>
                                    Gratis
                                    <?php elseif($item->type_kelas == 1): ?>
                                    Regular
                                    <?php elseif($item->type_kelas == 2): ?>
                                    Premium
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <img src="<?php echo e(asset('storage/' . $item->thumbnail)); ?>" width="200" alt="" srcset="">
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.kelas.detail',Crypt::encrypt($item->id))); ?>"
                                        class="btn btn-warning">Detail</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/admin/kelas/index.blade.php ENDPATH**/ ?>