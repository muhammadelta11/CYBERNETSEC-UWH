<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e($title); ?></h4>
                <div class="card-header-action">
                    <a href="<?php echo e(route('admin.podcast.tambah')); ?>" class="btn btn-primary">
                        Tambah
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-items-center table-hover" id="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No</th>
                                <th>Nama Podcast</th>
                                <th>URL Podcast</th>
                                <th>Thumbnail</th>
                                <th width="10%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $podcasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td><?php echo e($item->name_podcast); ?></td>
                                <td><?php echo e($item->url_podcast); ?></td>
                                <td>
                                    <img src="http://img.youtube.com/vi/<?php echo e($item->url_podcast); ?>/0.jpg" width="200"
                                        alt="" srcset="">
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.podcast.detail',Crypt::encrypt($item->id))); ?>"
                                        class="btn btn-warning">Detail</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/admin/podcast/index.blade.php ENDPATH**/ ?>