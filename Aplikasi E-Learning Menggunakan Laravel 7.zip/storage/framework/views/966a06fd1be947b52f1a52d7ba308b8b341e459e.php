<?php $__env->startSection('content'); ?>

<!-- breadcrumb start-->

<!--================ Start Course Details Area =================-->
<section class="course_details_area section_padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 course_details_left">
                <div class="main_image">
                    <img class="img-fluid" src="img/single_cource.png" alt="">
                </div>
                <div class="content_wrapper">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item"
                            src="https://www.youtube.com/embed/<?php echo e($video->url_video); ?>" allowfullscreen></iframe>
                    </div>
                    <h4 class="title_top"><?php echo e($video->name_video); ?></h4>
                </div>
            </div>


            <div class="col-lg-4 right-contents">
                <div class="sidebar_top">
                    <ul>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Kelas</p>
                                <span class="color"><?php echo e($kelas->name_kelas); ?></span>
                            </a>
                        </li>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Tipe Kelas </p>
                                <span>
                                    <?php if($kelas->type_kelas == 0): ?>
                                    Gratis
                                    <?php elseif($kelas->type_kelas == 1): ?>
                                    Regular
                                    <?php elseif($kelas->type_kelas == 2): ?>
                                    Premium
                                    <?php endif; ?>
                                </span>
                            </a>
                        </li>
                        <li>
                            <div>
                                <p class="mb-2">Daftar Materi </p>
                                <?php $__currentLoopData = $kelas->video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <a class="btn <?php echo e($video->id == $item->id ? 'btn-warning text-white' : 'btn-light'); ?> mb-3 btn-block"
                                        href="<?php echo e(route('kelas.belajar',[
                                        'id' => Crypt::encrypt($kelas->id),
                                        'idvideo' => Crypt::encrypt($item->id)
                                    ])); ?>"><?php echo e($item->name_video); ?></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Course Details Area =================-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/front/kelas/belajar.blade.php ENDPATH**/ ?>