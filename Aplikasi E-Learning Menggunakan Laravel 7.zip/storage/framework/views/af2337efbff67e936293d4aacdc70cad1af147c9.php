<?php $__env->startSection('content'); ?>

<!--::review_part start::-->
<section class="special_cource padding_top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5">
                <div class="section_tittle text-center">
                    <h2>Blog</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-lg-4 mb-2">
                <a href="<?php echo e(route('blog.detail',Crypt::encrypt($item->id))); ?>">
                    <div class="single_special_cource">
                    <img src="<?php echo e(asset('storage/'.$item->thumbnail_blog)); ?>" class="special_img" alt="">
                        <div class="special_cource_text">
                            <div class="d-flex justify-content-between">
                                <div class="btn_4">
                                    <?php echo e(substr($item->created_at,0,10)); ?>

                                </div> 
                                <a href="<?php echo e(route('blog.detail',Crypt::encrypt($item->id))); ?>"
                                    class="btn btn-secondary">Lihat</a>
                            </div>
                            <a href="<?php echo e(route('blog.detail',Crypt::encrypt($item->id))); ?>">
                                <h3><?php echo e($item->name_blog); ?></h3>
                            </a>
                      
                        </div>

                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row mt-3">
            <div class="col-md-12 d-flex justify-content-center">
                <?php echo e($blogs->links()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gratis-elearning\resources\views/front/blog/index.blade.php ENDPATH**/ ?>